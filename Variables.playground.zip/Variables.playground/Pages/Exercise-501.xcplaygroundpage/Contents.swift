/*:
 ## Exercise: 501
 
 You may know the popular darts game called 501. Players start with a score of 501, and have to work down to zero. Here are the rules:
 
 - Each player plays a “round” where they throw three darts at a board.
 - Each throw can score between 1 and 20 points, which may be doubled or tripled depending where it hits on the board.
 - It is also possible to score 25 for the outer bulls-eye or 50 for the inner bulls-eye.
 
 House rule: At the end of three rounds, whoever is closest to zero without going below zero is the winner.
 
 - callout(Exercise): Imagine you’re a game shark. You want to fool people into thinking you’re terrible at this game, but then come back and beat them in one swoop at the end. Model your game progress using variables.\
 \
 Start with a variable set to `501` to hold your overall score.\
 Create another variable set to `0` to hold the score for each round.\
 For each throw, update the value of the round score by adding points from the throw.\
 At the end of each round, calculate your current overall score by subtracting the round score from it. Assign the new value to your overall score, and re-set the round score to zero.\
 \
 How slowly can you “improve” your performance without arousing suspicion? \
 \
 After each round, `print` some statements that your opponents might make. If you can, use the value of your current score in their statements.
 */
//Scores
let scorenoob = 5
let scoreok = 10
let scoregood = 15
let scoregreat = 20
let scoreouterbullseye = 25
let scoreinnerbullseye = 50

//players score
var scoreforOrlando = 501
var scoreforDave = 501

//Game start scores
scoreforOrlando -= scorenoob
scoreforOrlando -= scorenoob
scoreforOrlando -= scorenoob

scoreforDave -= scoregood
scoreforDave -= scoregreat
scoreforDave -= scoregood

scoreforOrlando -= scoregood
scoreforOrlando -= scorenoob
scoreforOrlando -= scoreok

scoreforDave -= scoregood
scoreforDave -= scoregreat
scoreforDave -= scoregreat

scoreforOrlando -= scoregood
scoreforOrlando -= scorenoob
scoreforOrlando -= scoregreat

scoreforDave -= scoregreat
scoreforDave -= scoregreat
scoreforDave -= scoregreat

scoreforOrlando -= scoregood
scoreforOrlando -= scoregreat
scoreforOrlando -= scoregreat

scoreforDave -= scoregreat
scoreforDave -= scoreouterbullseye
scoreforDave -= scoreinnerbullseye

scoreforOrlando -= scoregood
scoreforOrlando -= scorenoob
scoreforOrlando -= scoreok

scoreforDave -= scoreinnerbullseye
scoreforDave -= scoreouterbullseye
scoreforDave -= scoreinnerbullseye

scoreforOrlando -= scoreinnerbullseye
scoreforOrlando -= scoreinnerbullseye
scoreforOrlando -= scoreinnerbullseye

scoreforDave -= scoreouterbullseye
scoreforDave -= scoreouterbullseye
scoreforDave -= scoreouterbullseye

scoreforOrlando -= scoreinnerbullseye
scoreforOrlando -= scoreinnerbullseye
scoreforOrlando -= scoreinnerbullseye

scoreforDave -= scorenoob
scoreforDave -= scoregood
scoreforDave -= scoregood

scoreforOrlando -= scoregood
scoreforOrlando -= scoreok
scoreforOrlando -= scorenoob

"Winner"
"Orlando"
